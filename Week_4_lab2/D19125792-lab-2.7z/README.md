This is Lab 2. 
Github link - https://github.com/ayanabedin1105/Rich-Web-Applications.git