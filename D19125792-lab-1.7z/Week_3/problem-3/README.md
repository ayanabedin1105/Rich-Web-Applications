Based on the given **Content.js** file, the following changes have been made - 
1. A paragrah tag with an id *intro* is created showing the demonstration of **getElementById** tag.
2. Based on the given array of images and using **Math.ramdom** function, a new heading tag **h2** is created using the array function to show random strings from an array of strings.
3. A Styling element property is used to change the color of the paragraph tag.